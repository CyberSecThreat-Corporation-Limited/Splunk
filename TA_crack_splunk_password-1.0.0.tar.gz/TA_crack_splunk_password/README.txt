Crack Splunk Password Add-on for Splunk
Copyright (C) 2021 CyberSecThreat Corporation Limited. All Rights Reserved.

================================================
Overview
================================================

This app can be installed on any Splunk instance where you need to crack the password.

If you are not need to crack production password from another machine, you need to copy $SPLUNK_HOME/etc/auth/splunk.secret from the target Splunk instance.

================================================
Steps to Crack Splunk Password:
================================================

1. Refer to example from $SPLUNK_HOME/etc/apps/TA_crack_splunk_password/default/app.conf, and configure $SPLUNK_HOME/etc/apps/TA_crack_splunk_password/local/app.conf
2. If you need to crack production password from another machine, you need to copy $SPLUNK_HOME/etc/auth/splunk.secret from the target Splunk production instance.
3. Restart Splunk instance after install the app
4. Execute: $SPLUNK_HOME/bin/splunk cmd python $SPLUNK_HOME/etc/apps/TA_crack_splunk_password/bin/crack_splunk_password.py

================================================
Configuring Splunk
================================================
This app can be installed on any Splunk instance where you need to crack the password.

If you are not need to crack production password from another machine, you need to copy $SPLUNK_HOME/etc/auth/splunk.secret from the target Splunk instance.

Install this app into Splunk by doing the following:

  1. Log in to Splunk Web and navigate to "Apps » Manage Apps" via the app dropdown at the top left of Splunk's user interface
  2. Click the "install app from file" button
  3. Upload the file by clicking "Choose file" and selecting the app
  4. Click upload
  5. Restart Splunk if a dialog asks you to

================================================
Known Limitations
================================================

N/A



================================================
Getting Support
================================================

This is an open source project and no active support is provided. If there is any issues, email to info@cybersecthreat.com during weekday business hours (GMT+8).




================================================
Change History
================================================

+---------+------------------------------------------------------------------------------------------------------------------+
| Version |  Changes                                                                                                         |
+---------+------------------------------------------------------------------------------------------------------------------+
| 1.0.0   | Initial release                                                                                                  |
|---------|------------------------------------------------------------------------------------------------------------------|